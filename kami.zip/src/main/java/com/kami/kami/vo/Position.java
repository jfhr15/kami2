package com.kami.kami.vo;

public class Position {
	private int positionseq;
	private String position; //직책
	private int salary; //급여정보
}
